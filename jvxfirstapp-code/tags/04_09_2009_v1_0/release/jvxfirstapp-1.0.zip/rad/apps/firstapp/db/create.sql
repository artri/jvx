-------------------------------------------------------------------------------
-- Tables
-------------------------------------------------------------------------------

create table CONTACTS
(
  ID            INTEGER IDENTITY,
  FIRSTNAME     VARCHAR(200) not null,
  LASTNAME      VARCHAR(200) not null,
  BIRTHDAY      DATE,
  STREET        VARCHAR(200),
  NR            VARCHAR(200),
  ZIP           VARCHAR(4),
  TOWN          VARCHAR(200)
)
