-------------------------------------------------------------------------------
-- Tables
-------------------------------------------------------------------------------

create table CONTACTS
(
  ID            INTEGER IDENTITY,
  FIRSTNAME     VARCHAR(200) not null,
  LASTNAME      VARCHAR(200) not null,
  BIRTHDAY      DATE,
  STREET        VARCHAR(200),
  NR            VARCHAR(200),
  ZIP           VARCHAR(4),
  TOWN          VARCHAR(200)
)

INSERT INTO CONTACTS (ID, FIRSTNAME, LASTNAME, BIRTHDAY, STREET, NR, ZIP, TOWN) VALUES (1, 'Johann', 'M�ller', '1947-03-12', 'Berggasse', 12, 2610, 'Alpstadt');
INSERT INTO CONTACTS (ID, FIRSTNAME, LASTNAME, BIRTHDAY, STREET, NR, ZIP, TOWN) VALUES (2, 'Leona', 'Sommer', '1982-06-01', 'Landstrasse', 29, 1020, 'Wien');

